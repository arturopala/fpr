<!-- pagination -->
<div class="pagination">
	<?php fpr_pagination(); ?>
</div>
<!-- /pagination -->
